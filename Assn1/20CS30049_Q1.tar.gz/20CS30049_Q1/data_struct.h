//wrapper to call all data structure implementations at once

#include <data_struct/llist.h>
#include <data_struct/stack.h>
#include <data_struct/queue.h>
#include <data_struct/heap.h>
#include <data_struct/union_find.h>

